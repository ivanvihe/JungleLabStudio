import sys
from ui import MainApplication

if __name__ == "__main__":
    app = MainApplication()
    sys.exit(app.run())